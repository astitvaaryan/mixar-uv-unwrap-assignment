# Required so Blender can import core.cache
